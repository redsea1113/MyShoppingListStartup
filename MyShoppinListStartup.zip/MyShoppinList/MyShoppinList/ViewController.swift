//
//  ViewController.swift
//  MyShoppingList
//
//  Created by AFARHAT on 11/14/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtUser: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }



}

