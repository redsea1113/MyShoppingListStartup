//
//  ItemViewController.swift
//  MyShoppingList
//
//  Created by AFARHAT on 11/14/21.
//

import UIKit

class ItemViewController: UIViewController {

   
    // Create an object of my Helper class
    
    @IBOutlet weak var lblGreetign: UILabel!
    @IBOutlet weak var txtType: UITextField!
    @IBOutlet weak var txtDesc: UITextField!
    @IBOutlet weak var txtName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
         
        // Do any additional setup after loading the view.
    }

   
    @IBAction func btnAdd(_ sender: Any) {
        
       
    }
    
    @IBAction func btnFind(_ sender: Any) {
        
        
     }
    
    @IBAction func btnCancel(_ sender: Any) {
        
        // dismiss the curren view controller
        self.dismiss(animated: true, completion: nil)
    }
    
}
